module.exports = function parseStringAsArray(string){

    const array =  string.split(',').map(tech=>tech.trim());
    
    return array;
}