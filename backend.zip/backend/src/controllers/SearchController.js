const Dev = require('../models/Dev');
const ParseString = require('../utils/parseStringAsArray');


module.exports = {
    async index(request, response){

        const{ latitude, logitude, techs};

        const techsArray = ParseString(techs);

        const devs = await Dev.find({
            techs:{
                $in: techsArray
            },
            location:{
                $near:{
                    $geometry:{
                        type: 'Point',
                        coordinates: [longitude, latitude],
                    }
                },
                $maxDistance: 10000,
            }
        })

    }
}